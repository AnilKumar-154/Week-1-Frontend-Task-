const pages = {
  home: "<h1>Welcome Home</h1><p>This is my Single Page Application.</p>",
  about: "<h1>About</h1><p>This SPA uses HTML, CSS and JavaScript.</p>",
  contact: "<h1>Contact</h1><p>Email: example@gmail.com</p>"
};

function showPage(page, updateHistory = true) {
  document.getElementById("app").innerHTML =
    pages[page] || pages.home;

  if (updateHistory) {
    history.pushState({ page: page }, "", "#" + page);
  }
}

window.addEventListener("popstate", () => {
  const page = location.hash.substring(1) || "home";
  showPage(page, false);
});

const firstPage = location.hash.substring(1) || "home";
showPage(firstPage, false);
